#include<stdio.h>

int main(){

    int x = 10;
    int y = 20;
    
    y -= x;
    x += y;
    printf("The value of x after swapping is : %d\n", x);
    printf("The value of x after swapping is : %d", y);

return 0;

}
