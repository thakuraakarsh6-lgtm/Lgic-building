#include <stdio.h>

int main()
{

    int x;
    printf("X : ");
    scanf("%d", &x);
    int y;
    printf("y : ");
    scanf("%d", &y);

    printf("The sum of both no. is %d.", x + y);

    return 0;
}
