#include<stdio.h>

int main(){

    int num;
    int divi;
    printf("Enter the value of num : ");
    scanf("%d", &num);

    divi = num/(-5);
    printf("Value after negative divisibility test is : %d", divi);

return 0;

}
